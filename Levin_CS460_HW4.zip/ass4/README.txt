Build:
make
./main

Controls:
t - switch to teapot mode
    click and move mouse to rotate teapot
    w, s - zoom in and out
f - switch to flower mode
    r - rotate flower 30 degrees
    click flower and drag - deform flower
    click again to release
