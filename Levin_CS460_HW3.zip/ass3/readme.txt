make - compiles program
./main - runs program

controls
w , s - controls pitch
a , d - controls yaw
q , e - controls rotate
i , k - controls forward slide
j , l - controls horizontal slide
u , o - controls vertical slide
r - controls lever rotation

